package com.sismoda.moda.servicio;

import com.sismoda.moda.modelo.Categoria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface CategoriaService extends ICrudGenericoService<Categoria, Long> {

}
