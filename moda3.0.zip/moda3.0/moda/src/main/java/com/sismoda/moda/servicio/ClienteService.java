package com.sismoda.moda.servicio;


import com.sismoda.moda.modelo.Cliente;

public interface ClienteService extends ICrudGenericoService<Cliente, Long> {
}
