package com.sismoda.moda.servicio;

import com.sismoda.moda.dtos.ProductoDTO;
import com.sismoda.moda.modelo.Producto;

public interface ProductoService extends ICrudGenericoService<Producto, Long> {

}
