package com.sismoda.moda.servicio;

import com.sismoda.moda.modelo.Cargo;

public interface CargoService extends ICrudGenericoService<Cargo, Long> {

}
