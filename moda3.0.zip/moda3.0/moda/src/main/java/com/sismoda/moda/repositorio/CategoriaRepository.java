package com.sismoda.moda.repositorio;

import com.sismoda.moda.modelo.Categoria;

public interface CategoriaRepository extends ICrudGenericoRepository<Categoria, Long> {
}
