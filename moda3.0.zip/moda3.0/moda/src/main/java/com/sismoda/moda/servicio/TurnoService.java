package com.sismoda.moda.servicio;

import com.sismoda.moda.modelo.Turno;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TurnoService extends ICrudGenericoService<Turno, Long>{

}
