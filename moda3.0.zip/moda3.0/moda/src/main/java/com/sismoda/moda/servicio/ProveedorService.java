package com.sismoda.moda.servicio;

import com.sismoda.moda.modelo.Proveedor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProveedorService extends ICrudGenericoService<Proveedor, Long> {

}
