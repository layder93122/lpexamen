package com.sismoda.moda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModaApplication.class, args);
	}

}
