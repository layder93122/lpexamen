package com.sismoda.moda.repositorio;

import com.sismoda.moda.modelo.Producto;

public interface ProductoRepository extends ICrudGenericoRepository<Producto, Long> {
}
