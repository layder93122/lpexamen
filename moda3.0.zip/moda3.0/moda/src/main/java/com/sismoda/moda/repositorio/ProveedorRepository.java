package com.sismoda.moda.repositorio;

import com.sismoda.moda.modelo.Proveedor;

public interface ProveedorRepository extends ICrudGenericoRepository<Proveedor, Long> {
}
