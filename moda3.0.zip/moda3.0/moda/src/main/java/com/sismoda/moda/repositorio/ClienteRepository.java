package com.sismoda.moda.repositorio;

import com.sismoda.moda.modelo.Cliente;

public interface ClienteRepository extends ICrudGenericoRepository<Cliente, Long>{
}
