package com.sismoda.moda.servicio;

import com.sismoda.moda.dtos.TrabajadorDTO;
import com.sismoda.moda.modelo.Trabajador;

public interface TrabajadorService extends ICrudGenericoService<Trabajador, Long>{

}
