package com.sismoda.moda.repositorio;

import com.sismoda.moda.modelo.Turno;

public interface TurnoRepository extends ICrudGenericoRepository<Turno, Long>{
}
