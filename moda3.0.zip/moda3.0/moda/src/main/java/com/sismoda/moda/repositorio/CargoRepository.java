package com.sismoda.moda.repositorio;

import com.sismoda.moda.modelo.Cargo;

public interface CargoRepository extends ICrudGenericoRepository<Cargo, Long>{
}
