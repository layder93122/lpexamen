export class Trabajador {
  idTrabajador: number
  nombre: string
  apellido: string
  contrasena: string
  cargo: string
  turno: string
}
