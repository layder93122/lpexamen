export class Turno{
  idTurno: number
  nombre: string
}
