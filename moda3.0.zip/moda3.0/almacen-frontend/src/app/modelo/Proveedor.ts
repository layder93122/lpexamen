export class Proveedor {
  idProveedor: number
  nombre: string
}
