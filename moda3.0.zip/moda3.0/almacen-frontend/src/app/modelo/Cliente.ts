export class Cliente{
  idCliente: number
  dnirucCliente: string
  nombreCliente: string
  apellidoCliente: string
  telefonoCliente: string
  correoCliente: string
  direccionCliente: string
}
