export class Cargo{
  idCargo: number
  nombreCargo: string
}
