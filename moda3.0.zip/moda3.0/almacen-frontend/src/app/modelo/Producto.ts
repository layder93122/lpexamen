export class Producto {
  idProducto: number
  nombre: string
  cantidad: number
  categoria: string
  proveedor: string
}
